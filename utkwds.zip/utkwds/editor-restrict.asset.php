<?php return array('dependencies' => array(), 'version' => '0861f16e403aa7ba714b');
