<?php return array('dependencies' => array(), 'version' => '6c1ba27ced74ea79b645');
