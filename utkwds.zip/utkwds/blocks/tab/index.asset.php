<?php return array('dependencies' => array('react', 'wp-block-editor', 'wp-blocks', 'wp-url'), 'version' => '821817216d0197b12a2a');
