<?php return array('dependencies' => array('react-jsx-runtime', 'wp-block-editor', 'wp-blocks', 'wp-url'), 'version' => '4280a4eaee2567677030');
