<?php return array('dependencies' => array('react', 'wp-block-editor', 'wp-blocks', 'wp-url'), 'version' => '2b30e7786240228e658c');
