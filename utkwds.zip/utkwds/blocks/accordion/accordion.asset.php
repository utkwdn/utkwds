<?php return array('dependencies' => array(), 'version' => '8208e29586fc37f8c1fa');
