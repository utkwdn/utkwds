<?php return array('dependencies' => array(), 'version' => '88e73bd7a0f8b1bf3af3');
