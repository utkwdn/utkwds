<?php return array('dependencies' => array(), 'version' => '447b8da7f682eb43b25d');
