<?php return array('dependencies' => array(), 'version' => '2a7cba823e28e6240a71');
