<?php
/**
 * Title: Fancy link group light gray
 * Slug: utkwds/cta-link-group-light-gray
 * Description:
 * Categories: links
 * Keywords: fancy link, light
 * Viewport Width: 460
 * Block Types:
 * Post Types:
 * Inserter: false
 *
 * @package utkwds
 */

?>

<!-- wp:list {"backgroundColor":"light","className":"utkwds-cta-link-group is-style-no-disc has-light-background has-background"} -->
<ul class="utkwds-cta-link-group is-style-no-disc has-light-background has-background has-light-background-color"><!-- wp:list-item -->
<li><a href="https://www.utk.edu/">CTA Link</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://www.utk.edu/">CTA Link</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://www.utk.edu/">CTA Link</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
