<?php
/**
 * Title: Posts 2up + image light gray
 * Slug: utkwds/posts-2up-image-light-gray
 * Description: Dynamic feed highlighting two recent posts (e.g. news articles, announcements, etc.), showing featured image, title, date of publication, and an animated orange arrow, on a light gray backgorund.
 * Categories: dynamic-content
 * Keywords: posts, news, feed, articles, announcements, light gray, featured image
 * Viewport Width: 1500
 * Block Types:
 * Post Types:
 * Inserter: true
 *
 * @package utkwds
 */

?>

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|small","right":"var:preset|spacing|small","bottom":"var:preset|spacing|small","left":"var:preset|spacing|small"},"blockGap":"var:preset|spacing|medium"}},"backgroundColor":"light","className":"utkwds-posts-2up","layout":{"type":"constrained"},"metadata":{"name":"Posts 2up + image light gray"}} -->
<div class="wp-block-group alignfull utkwds-posts-2up has-light-background-color has-background" style="padding-top:var(--wp--preset--spacing--small);padding-right:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--small)"><!-- wp:heading {"align":"wide"} -->
<h2 class="wp-block-heading alignwide">Posts 2up + image light gray</h2>
<!-- /wp:heading -->

<!-- wp:query {"queryId":0,"query":{"perPage":"2","pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"exclude","inherit":false},"align":"wide","layout":{"type":"constrained"}} -->
<div class="wp-block-query alignwide"><!-- wp:post-template {"align":"wide","layout":{"type":"grid","columnCount":2}} -->
<!-- wp:group {"layout":{"type":"flex","verticalAlignment":"top"}} -->
<div class="wp-block-group"><!-- wp:post-featured-image {"aspectRatio":"1","width":"158px","height":"158px","sizeSlug":"medium","style":{"layout":{"selfStretch":"fixed","flexSize":"158px"}}} /-->

<!-- wp:group {"className":"utkwds-post-2up-meta","layout":{"type":"default"}} -->
<div class="wp-block-group utkwds-post-2up-meta">
<!-- wp:post-title {"level":3,"isLink":true} /-->

<!-- wp:post-date /--></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
<!-- /wp:post-template --></div>
<!-- /wp:query --></div>
<!-- /wp:group -->
