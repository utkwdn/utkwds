<?php
/**
 * Title: 404 error content.
 * Slug: utkwds/404
 * Inserter: false
 *
 * @package utkwds
 */

?>

<!-- wp:heading {"level":1} -->
<h1><?php echo esc_html__( 'Not found, error 404', 'utkwds' ); ?></h1>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p><?php echo esc_html__( 'Oops, the page you are looking for does not exist or is no longer available. Everything is still awesome. Just use the search form to find your way.', 'utkwds' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:search {"width":75,"widthUnit":"%","showLabel":false,"buttonText":"Search"} /-->
