<?php
/**
 * Title: Homepage Option 1
 * Slug: utkwds/page-homepage-option-1
 * Categories: page-layouts
 * Block Types: core/post-content
 * Post Types: page
 *
 * @package utkwds
 */

?>

<!-- wp:pattern {"slug":"utkwds/hero-full-width"} /-->

<!-- wp:pattern {"slug":"utkwds/billboard-light-gray"} /-->

<!-- wp:pattern {"slug":"utkwds/media-text-cta-white"} /-->

<!-- wp:pattern {"slug":"utkwds/text-cta-media-white"} /-->

<!-- wp:pattern {"slug":"utkwds/points-of-pride-light-gray"} /-->

<!-- wp:pattern {"slug":"utkwds/large-small-orange"} /-->
