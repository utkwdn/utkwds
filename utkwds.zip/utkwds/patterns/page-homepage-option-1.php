<?php
/**
 * Title: Homepage Option 1
 * Slug: utkwds/page-homepage-option-1
 * Categories: page-layouts 
 */
?>

<!-- wp:pattern {"slug":"utkwds/full-width-hero"} /-->

<!-- wp:pattern {"slug":"utkwds/billboard-light-gray"} /-->

<!-- wp:pattern {"slug":"utkwds/media-text-cta-white"} /-->

<!-- wp:pattern {"slug":"utkwds/text-cta-media-white"} /-->

<!-- wp:pattern {"slug":"utkwds/points-of-pride-light-gray"} /-->

<!-- wp:pattern {"slug":"utkwds/large-small-orange"} /-->