<?php
/**
 * Title: Fancy link group white
 * Slug: utkwds/cta-link-group-white
 * Description:
 * Categories: links
 * Keywords: fancy link, white
 * Viewport Width: 460
 * Block Types:
 * Post Types:
 * Inserter: false
 *
 * @package utkwds
 */

?>

<!-- wp:list {"backgroundColor":"white","className":"utkwds-cta-link-group is-style-no-disc"} -->
<ul class="utkwds-cta-link-group is-style-no-disc has-white-background-color has-background"><!-- wp:list-item -->
<li><a href="https://www.utk.edu/">CTA Link</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://www.utk.edu/">CTA Link</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://www.utk.edu/">CTA Link</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
