<?php
/**
 * Title: Turnpike with Images
 * Slug: utkwds/page-turnpike-images
 * Categories: page-layouts
 *
 * @package utkwds
 */

?>

<!-- wp:pattern {"slug":"utkwds/media-text-cta-light-gray"} /-->

<!-- wp:pattern {"slug":"utkwds/stack-3up-light-gray"} /-->

<!-- wp:pattern {"slug":"utkwds/stack-3up-light-gray"} /-->

<!-- wp:pattern {"slug":"utkwds/stack-3up-light-gray"} /-->
