<?php
/**
 * Title: Fancy link group Smokey
 * Slug: utkwds/cta-link-group-smokey
 * Description:
 * Categories: links
 * Keywords: fancy link, smokey
 * Viewport Width: 460 
 * Block Types: 
 * Post Types: 
 * Inserter: false
 */

?>

<!-- wp:list {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"backgroundColor":"smokey","textColor":"white","className":"utkwds-cta-link-group is-style-no-disc has-light-background has-link-color"} -->
<ul class="utkwds-cta-link-group is-style-no-disc has-light-background has-link-color has-white-color has-smokey-background-color has-text-color has-background"><!-- wp:list-item -->
<li><a href="https://www.utk.edu/">CTA Link</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://www.utk.edu/">CTA Link</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://www.utk.edu/">CTA Link</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->