<?php
/**
 * Title: Landing Page
 * Slug: utkwds/page-landing
 * Categories: page-layouts
 *
 * @package utkwds
 */

?>

<!-- wp:pattern {"slug":"utkwds/text-cta-media-light-gray"} /-->

<!-- wp:pattern {"slug":"utkwds/stack-3up-light-gray"} /-->

<!-- wp:pattern {"slug":"utkwds/billboard-light-gray"} /-->

<!-- wp:pattern {"slug":"utkwds/text-cta-media-white"} /-->

<!-- wp:pattern {"slug":"utkwds/points-of-pride-light-gray"} /-->

<!-- wp:pattern {"slug":"utkwds/posts-3up-white"} /-->

<!-- wp:pattern {"slug":"utkwds/text-contact-smokey"} /-->
