<?php
/**
 * Title: Detail Option 2
 * Slug: utkwds/page-detail-option-2
 * Categories: page-layouts
 *
 * @package utkwds
 */

?>

<!-- wp:paragraph -->
<p>Qui nemo accusantium ullam vel voluptatem ut repudiandae consequatur. Praesentium aut labore omnis consequatur saepe dolorem omnis adipisci. Labore deleniti voluptatem nesciunt sint. Sed sit tenetur quos laborum unde corrupti et quos.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"is-style-utkwds-cta-link"} -->
<p class="is-style-utkwds-cta-link"><a href="https://www.utk.edu/">CTA Link</a></p>
<!-- /wp:paragraph -->

<!-- wp:pattern {"slug":"utkwds/text-cta-media-light-gray"} /-->
 
<!-- wp:heading -->
<h2 class="wp-block-heading">Heading</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Qui nemo accusantium ullam vel voluptatem ut repudiandae consequatur. Praesentium aut labore omnis consequatur saepe dolorem omnis adipisci. Labore deleniti voluptatem nesciunt sint. Sed sit tenetur quos laborum unde corrupti et quos.</p>
<!-- /wp:paragraph -->

<!-- wp:pattern {"slug":"utkwds/link-group-2up"} /-->

<!-- wp:pattern {"slug":"utkwds/large-small-orange"} /-->

<!-- wp:pattern {"slug":"utkwds/points-of-pride-white"} /-->
