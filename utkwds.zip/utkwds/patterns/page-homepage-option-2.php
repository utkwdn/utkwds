<?php
/**
 * Title: Homepage Option 2
 * Slug: utkwds/page-homepage-option-2
 * Categories: page-layouts
 * Block Types: core/post-content
 * Post Types: page
 *
 * @package utkwds
 */

?>

<!-- wp:pattern {"slug":"utkwds/text-cta-media-white"} /-->

<!-- wp:pattern {"slug":"utkwds/billboard-light-gray"} /-->

<!-- wp:pattern {"slug":"utkwds/stuck-3up-light-gray"} /-->

<!-- wp:pattern {"slug":"utkwds/quote-media-orange-light-gray"} /-->

<!-- wp:pattern {"slug":"utkwds/points-of-pride-smokey"} /-->

<!-- wp:pattern {"slug":"utkwds/large-small-orange"} /-->
