<?php
/**
 * Title: Subject white
 * Slug: utkwds/subject-white
 * Description:
 * Categories: content-cards
 * Keywords: subject, card, white
 * Viewport Width: 460
 * Block Types:
 * Post Types:
 * Inserter: false
 *
 * @package utkwds
 */

?>

<!-- wp:group {"templateLock":"contentOnly","style":{"spacing":{"blockGap":"var:preset|spacing|small","padding":{"bottom":"var:preset|spacing|small"}}},"backgroundColor":"white","className":"utkwds-subject","layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group utkwds-subject has-white-background-color has-background" style="padding-bottom:var(--wp--preset--spacing--small)"><!-- wp:image -->
<figure class="wp-block-image"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/image-placeholder-small.png') );?>" alt="image placeholder"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"textAlign":"center","style":{"spacing":{"padding":{"right":"var:preset|spacing|x-small","left":"var:preset|spacing|x-small"}}}} -->
<h3 class="wp-block-heading has-text-align-center" style="padding-right:var(--wp--preset--spacing--x-small);padding-left:var(--wp--preset--spacing--x-small)">Heading</h3>
<!-- /wp:heading --></div>
<!-- /wp:group -->
