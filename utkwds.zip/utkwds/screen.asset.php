<?php return array('dependencies' => array(), 'version' => '307b993ae0dc9edddfc1');
