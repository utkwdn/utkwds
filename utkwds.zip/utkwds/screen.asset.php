<?php return array('dependencies' => array(), 'version' => '37de6e6ed01142dd5148');
