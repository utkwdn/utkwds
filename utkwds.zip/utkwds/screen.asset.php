<?php return array('dependencies' => array(), 'version' => '9d9ce2f714c14c54ae2a');
