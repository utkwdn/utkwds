<?php return array('dependencies' => array(), 'version' => 'fbf12ff60c5565797b08');
