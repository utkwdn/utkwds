<?php return array('dependencies' => array(), 'version' => 'c049eef7d552743cd400');
