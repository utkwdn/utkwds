<?php return array('dependencies' => array(), 'version' => '0232da83e677198cc494');
