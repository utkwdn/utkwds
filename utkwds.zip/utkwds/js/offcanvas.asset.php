<?php return array('dependencies' => array(), 'version' => 'eb1da1645e9f8af8c81e');
