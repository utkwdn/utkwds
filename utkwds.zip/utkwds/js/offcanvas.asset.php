<?php return array('dependencies' => array(), 'version' => '696b0236ca6e605a7ca4');
