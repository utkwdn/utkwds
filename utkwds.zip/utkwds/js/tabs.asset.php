<?php return array('dependencies' => array(), 'version' => '8ab41a913059c84c738b');
