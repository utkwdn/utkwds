<?php return array('dependencies' => array(), 'version' => 'e21e1b5e0c9840d4f934');
