<?php return array('dependencies' => array(), 'version' => '441361a7424510832572');
