<?php return array('dependencies' => array(), 'version' => '65e2bda74028d3b2f264');
