<?php return array('dependencies' => array(), 'version' => 'fc76f7f08c03a49f2be7');
