<?php return array('dependencies' => array(), 'version' => 'ef174a6fc5bedd5179e3');
