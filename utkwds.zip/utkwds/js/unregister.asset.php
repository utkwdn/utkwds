<?php return array('dependencies' => array(), 'version' => '623d667cfd0ae781c815');
