<?php return array('dependencies' => array(), 'version' => 'd58da74d8e975e41591d');
