<?php return array('dependencies' => array(), 'version' => '83faff15d4876a48d8db');
