<?php return array('dependencies' => array(), 'version' => '1dc741f16178c527198b');
