<?php return array('dependencies' => array('wp-blocks', 'wp-i18n'), 'version' => '23f992e885de852773c9');
