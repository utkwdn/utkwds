<?php return array('dependencies' => array(), 'version' => 'f611a31919ba886d5347');
