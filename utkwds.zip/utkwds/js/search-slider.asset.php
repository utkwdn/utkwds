<?php return array('dependencies' => array(), 'version' => 'dc16f900cd2bb267c35d');
