<?php return array('dependencies' => array(), 'version' => 'a4ebc28e9b5c7ce8e298');
