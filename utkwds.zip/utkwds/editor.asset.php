<?php return array('dependencies' => array(), 'version' => 'a5fd79a2dcde2e26eed7');
