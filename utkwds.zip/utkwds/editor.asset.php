<?php return array('dependencies' => array(), 'version' => 'e6af66aa6cde73f0f26c');
