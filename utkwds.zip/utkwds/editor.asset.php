<?php return array('dependencies' => array(), 'version' => '31833a0fcdba7f39c02a');
