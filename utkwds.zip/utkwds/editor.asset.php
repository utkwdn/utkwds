<?php return array('dependencies' => array(), 'version' => 'ddf3796a29a0f5db5e43');
