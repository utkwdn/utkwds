<?php

wp_add_inline_script( 'my-script-handle', 'console.log("Test From PHP in WordPress");' );