<?php
/**
 * Footer template for the theme.
 *
 * @package utkwds
 */

?>

<footer class="wp-block-template-part site-footer">
<?php block_footer_area(); ?>
</footer>
</div>
<?php wp_footer(); ?>
</body>